import asyncio
from datetime import datetime
import os
import edge_tts
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes

AUTHORIZED_USERS = {"I_zhyrexx"}  # Replace with actual usernames
VOICE = "ml-IN-MidhunNeural"
RATE = "+23%"

async def synthesize_text_to_speech(text, filename):
    communicate = edge_tts.Communicate(text, VOICE, rate=RATE)
    await communicate.save(filename)

def is_valid_text(text: str):
    return text.strip().startswith("എല്ലാവർക്കും ")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    username = user.username
    content = update.message.text.strip()

    # 🔐 Authorization check
    if username not in AUTHORIZED_USERS:
        await update.message.reply_text("❌ Hi, Welcome to NewsFirst Group, You are not authorized to use this bot.")
        return

    # 🙋 Respond to greetings
    if content.lower() in ["hi", "hello"]:
        await update.message.reply_text("👋 Hi, Welcome to NewsFirst Group, Send a message in the format `Text=your message`.")
        return

    # 🧾 Format check
    if not content.startswith("Text="):
        await update.message.reply_text("❌ Hi, Welcome to NewsFirst Group, Invalid format. Please start your message with `Text=`.")
        return

    raw_text = content[5:].strip()

    # 📌 Text content check
    if not is_valid_text(raw_text):
        await update.message.reply_text("⚠️ Hi, Welcome to NewsFirst Group, This content is not eligible for getting voice.")
        return

    # ✅ Processing reply
    await update.message.reply_text("✅ Please wait while I process your audio...")

    timestamp = datetime.now().strftime("%d-%m-%Y_%H-%M-%S")
    filename = f"{timestamp}.mp3"

    await synthesize_text_to_speech(raw_text, filename)

    with open(filename, 'rb') as f:
        await update.message.reply_audio(audio=f, filename=filename, title="News First Group Audio", caption="Here is your audio message.")

    os.remove(filename)

# /start command
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 Hi, Welcome to NewsFirst Group, Send a message in the format `Text=your message`.")

def main():
    app = ApplicationBuilder().token("7364638777:AAHp3JgeIJZZ8b8p6kziAj8jq8QdP8SGu-Y").build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("🤖 Bot is running...")
    app.run_polling()

if __name__ == "__main__":
    main()
